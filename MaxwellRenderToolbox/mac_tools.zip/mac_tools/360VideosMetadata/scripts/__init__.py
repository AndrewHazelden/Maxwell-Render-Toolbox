"""
Python Init command for the
360VideosMetadata.py
Created by Andrew Hazelden  andrew@andrewhazelden.com
"""
